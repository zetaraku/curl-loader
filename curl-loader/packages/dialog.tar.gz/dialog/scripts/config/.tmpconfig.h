#ifndef BB_CONFIG_H
#define BB_CONFIG_H
/*
 * Automatically generated header file: don't edit
 */

/* Version Number */
#define BB_VER "(null)"
#define BB_BT "(null)"

#define HAVE_DOT_CONFIG 1
#define ENABLE_DOT_CONFIG 1
#define USE_DOT_CONFIG(...)  __VA_ARGS__
#define SKIP_DOT_CONFIG(...)


/*
 * Busybox Settings
 */

/*
 * General Configuration
 */
#undef NITPICK
#define ENABLE_NITPICK 0
#define USE_NITPICK(...)
#define SKIP_NITPICK(...)  __VA_ARGS__

#undef DESKTOP
#define ENABLE_DESKTOP 0
#define USE_DESKTOP(...)
#define SKIP_DESKTOP(...)  __VA_ARGS__

#undef FEATURE_BUFFERS_USE_MALLOC
#define ENABLE_BUFFERS_USE_MALLOC 0
#define USE_BUFFERS_USE_MALLOC(...)
#define SKIP_BUFFERS_USE_MALLOC(...)  __VA_ARGS__

#undef FEATURE_BUFFERS_GO_ON_STACK
#define ENABLE_BUFFERS_GO_ON_STACK 0
#define USE_BUFFERS_GO_ON_STACK(...)
#define SKIP_BUFFERS_GO_ON_STACK(...)  __VA_ARGS__

#undef FEATURE_BUFFERS_GO_IN_BSS
#define ENABLE_BUFFERS_GO_IN_BSS 0
#define USE_BUFFERS_GO_IN_BSS(...)
#define SKIP_BUFFERS_GO_IN_BSS(...)  __VA_ARGS__

#define SHOW_USAGE 1
#define ENABLE_USAGE 1
#define USE_USAGE(...)  __VA_ARGS__
#define SKIP_USAGE(...)

#undef FEATURE_VERBOSE_USAGE
#define ENABLE_VERBOSE_USAGE 0
#define USE_VERBOSE_USAGE(...)
#define SKIP_VERBOSE_USAGE(...)  __VA_ARGS__

#define FEATURE_COMPRESS_USAGE 1
#define ENABLE_COMPRESS_USAGE 1
#define USE_COMPRESS_USAGE(...)  __VA_ARGS__
#define SKIP_COMPRESS_USAGE(...)

#undef FEATURE_INSTALLER
#define ENABLE_INSTALLER 0
#define USE_INSTALLER(...)
#define SKIP_INSTALLER(...)  __VA_ARGS__

#undef LOCALE_SUPPORT
#define ENABLE_SUPPORT 0
#define USE_SUPPORT(...)
#define SKIP_SUPPORT(...)  __VA_ARGS__

#define GETOPT_LONG 1
#define ENABLE_LONG 1
#define USE_LONG(...)  __VA_ARGS__
#define SKIP_LONG(...)

#define FEATURE_DEVPTS 1
#define ENABLE_DEVPTS 1
#define USE_DEVPTS(...)  __VA_ARGS__
#define SKIP_DEVPTS(...)

#undef FEATURE_CLEAN_UP
#define ENABLE_CLEAN_UP 0
#define USE_CLEAN_UP(...)
#define SKIP_CLEAN_UP(...)  __VA_ARGS__

#undef FEATURE_SUID
#define ENABLE_SUID 0
#define USE_SUID(...)
#define SKIP_SUID(...)  __VA_ARGS__

#undef FEATURE_SYSLOG
#define ENABLE_SYSLOG 0
#define USE_SYSLOG(...)
#define SKIP_SYSLOG(...)  __VA_ARGS__

#undef FEATURE_SUID_CONFIG
#define ENABLE_SUID_CONFIG 0
#define USE_SUID_CONFIG(...)
#define SKIP_SUID_CONFIG(...)  __VA_ARGS__

#undef FEATURE_SUID_CONFIG_QUIET
#define ENABLE_SUID_CONFIG_QUIET 0
#define USE_SUID_CONFIG_QUIET(...)
#define SKIP_SUID_CONFIG_QUIET(...)  __VA_ARGS__

#define FEATURE_HAVE_RPC 1
#define ENABLE_HAVE_RPC 1
#define USE_HAVE_RPC(...)  __VA_ARGS__
#define SKIP_HAVE_RPC(...)

#undef SELINUX
#define ENABLE_SELINUX 0
#define USE_SELINUX(...)
#define SKIP_SELINUX(...)  __VA_ARGS__

#define BUSYBOX_EXEC_PATH "/proc/self/exe"
#define ENABLE_EXEC_PATH 1
#define USE_EXEC_PATH(...)  __VA_ARGS__
#define SKIP_EXEC_PATH(...)


/*
 * Build Options
 */
#undef STATIC
#define ENABLE_STATIC 0
#define USE_STATIC(...)
#define SKIP_STATIC(...)  __VA_ARGS__

#undef BUILD_LIBBUSYBOX
#define ENABLE_LIBBUSYBOX 0
#define USE_LIBBUSYBOX(...)
#define SKIP_LIBBUSYBOX(...)  __VA_ARGS__

#undef FEATURE_FULL_LIBBUSYBOX
#define ENABLE_FULL_LIBBUSYBOX 0
#define USE_FULL_LIBBUSYBOX(...)
#define SKIP_FULL_LIBBUSYBOX(...)  __VA_ARGS__

#undef FEATURE_SHARED_BUSYBOX
#define ENABLE_SHARED_BUSYBOX 0
#define USE_SHARED_BUSYBOX(...)
#define SKIP_SHARED_BUSYBOX(...)  __VA_ARGS__

#undef LFS
#define ENABLE_LFS 0
#define USE_LFS(...)
#define SKIP_LFS(...)  __VA_ARGS__

#undef BUILD_AT_ONCE
#define ENABLE_AT_ONCE 0
#define USE_AT_ONCE(...)
#define SKIP_AT_ONCE(...)  __VA_ARGS__


/*
 * Debugging Options
 */
#undef DEBUG
#define ENABLE_DEBUG 0
#define USE_DEBUG(...)
#define SKIP_DEBUG(...)  __VA_ARGS__

#undef DEBUG_PESSIMIZE
#define ENABLE_PESSIMIZE 0
#define USE_PESSIMIZE(...)
#define SKIP_PESSIMIZE(...)  __VA_ARGS__

#undef NO_DEBUG_LIB
#define ENABLE_DEBUG_LIB 0
#define USE_DEBUG_LIB(...)
#define SKIP_DEBUG_LIB(...)  __VA_ARGS__

#undef DMALLOC
#define ENABLE_DMALLOC 0
#define USE_DMALLOC(...)
#define SKIP_DMALLOC(...)  __VA_ARGS__

#undef EFENCE
#define ENABLE_EFENCE 0
#define USE_EFENCE(...)
#define SKIP_EFENCE(...)  __VA_ARGS__

#define INCLUDE_SUSv2 1
#define ENABLE_SUSv2 1
#define USE_SUSv2(...)  __VA_ARGS__
#define SKIP_SUSv2(...)


/*
 * Installation Options
 */
#undef INSTALL_NO_USR
#define ENABLE_NO_USR 0
#define USE_NO_USR(...)
#define SKIP_NO_USR(...)  __VA_ARGS__

#define INSTALL_APPLET_SYMLINKS 1
#define ENABLE_APPLET_SYMLINKS 1
#define USE_APPLET_SYMLINKS(...)  __VA_ARGS__
#define SKIP_APPLET_SYMLINKS(...)

#undef INSTALL_APPLET_HARDLINKS
#define ENABLE_APPLET_HARDLINKS 0
#define USE_APPLET_HARDLINKS(...)
#define SKIP_APPLET_HARDLINKS(...)  __VA_ARGS__

#undef INSTALL_APPLET_DONT
#define ENABLE_APPLET_DONT 0
#define USE_APPLET_DONT(...)
#define SKIP_APPLET_DONT(...)  __VA_ARGS__

#define PREFIX "./_install"
#define ENABLE_PREFIX 1
#define USE_PREFIX(...)  __VA_ARGS__
#define SKIP_PREFIX(...)


/*
 * Applets
 */
#endif /* BB_CONFIG_H */
